package project;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

 class FacultyManagement {
	Connection con;
	PreparedStatement st;
	ResultSet rs;
	
	
     FacultyManagement()  {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/facultydb?verifyServerCertificate=false&useSSL=true";
			String username = "root";
			String password ="12345";
			con= DriverManager.getConnection(url, username, password); 
		} catch (Exception e) {
			e.printStackTrace();
			}
	}
	void closeresources() {
		try {
			if(rs != null) rs.close();
			if(st != null) st.close();
			if(con != null) con.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
  
    
	public void facultyadd()  {
		try {
		System.out.println("ENTER THE FACULTY DETAILS  ");
		Scanner scanner = new Scanner(System.in);
		System.out.println("----------------------------------");
		System.out.print("ID           : ");
		String Id=scanner.next();
		
		System.out.print("NAME         : ");
		scanner.nextLine();
		String name=scanner.nextLine();
		
		System.out.print("DEPARTMENT   : ");
		String department=scanner.nextLine();
		
		System.out.print("SALARY       : ");
		double salary=scanner.nextDouble();
		
		System.out.println("-------------------------------------");
		String query="insert into facultydetails (id,name,dept,salary) values(?,?,?,?)";
		st=con.prepareStatement(query);
		st.setString(1, Id);
		st.setString(2, name);
		st.setString(3, department);
		st.setDouble(4, salary);
		
		st.executeUpdate();
		System.out.println("Faculty details Added Successfully.");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	public void facultydisplay() {
		
		try {
			System.out.println("2.Display the data ");
			System.out.println("ID\t   NAME\t           DEPARTMENT\t    SALARY");
			System.out.println(" ");
			Statement stmt = con.createStatement();
			String qry = "SELECT Id,name,dept,salary FROM facultydetails ";
			rs = stmt.executeQuery(qry);
			
			while(rs.next()) {
				String Id = rs.getString("ID");
				String name=rs.getString("name");
				String department=rs.getString("dept");
				double salary=rs.getInt("salary");
				
				System.out.print(Id + " ");
				System.out.print("\t"+name +"\t");
				System.out.print("\t"+department +"\t");
				System.out.print("\t"+salary +"\t");
				System.out.println(" ");
			}
			
			
		} catch (SQLException e) {e.printStackTrace();}
		
		
	}
	public void facultyupdate() {
		try {
			System.out.println("3.Update a patient details");
			Scanner in = new Scanner(System.in);
			
			System.out.println("Enter Id : ");
			String Id = in.nextLine();
			
			System.out.println("Enter Name : ");
			String name = in.nextLine();
			
			System.out.println("Enter department : ");
			String department = in.nextLine();
			
			System.out.println("Enter Salary : ");
			Double salary = in.nextDouble();
			
			String qry = "UPDATE facultydetails SET id=?,name=?,dept=?,salary=?";
			st = con.prepareStatement(qry);
			
			
			st.setString(1, Id);
			st.setString(2, name);
			st.setString(3, department);
			st.setDouble(4, salary);
			
			st.executeUpdate();
			System.out.println("Data Update successfully");
		}
		catch(Exception e) {e.printStackTrace();}
	}
	
	public void facultydelete() {
		try{
			Scanner in = new Scanner(System.in);
			System.out.println("4.Deleting a Data");
			System.out.println("Enter Id : ");
			String Id=in.next();
			
			String qry = "delete From facultydetails where Id=?";
			st=con.prepareStatement(qry);
			st.setString(1,Id);
			
			st.executeUpdate();
			System.out.println("Data deleted Successfully");
			System.out.println("");
		}
		catch(Exception e){e.printStackTrace();}
	}	
	
public static void main(String[] args) throws SQLException
{
		FacultyManagement ob = new FacultyManagement();
		Scanner scanner = new Scanner(System.in);
		
		try
		{
			System.out.println("------------------------------"
         		+ "\nFaculty Management System"
         		+ "\n------------------------------");
		 System.out.println("Admin mode");
    	 for(int i=0;i<3;i++)
    	 {
    		System.out.println("Enter the Password:");
 		 	String code=scanner.next();
 		 	boolean equals=code.equals("Admin");
 		 	if(equals==true)
 		 	{
 		 
 		 		while(true) 
 		 		{
 		 			System.out.println("Faculty Management System");
 		 			System.out.println("-------------------------");
 		 			System.out.println("1.Insert Faculty Details");
 		 			System.out.println("2.Display FacultyList");
 		 			System.out.println("3.Update Faculty Details");
 		 			System.out.println("4 Delete Faculty Details");
 		 			System.out.println("5.Exit");
 		 			System.out.println("-------------------------");
 		 			System.out.print("Enter your choice :");
 		 			int choice = scanner.nextInt();
 		 			switch(choice) {
 		 			 case 1 :
 		 				 ob.facultyadd();
 		 				 break;
 		 			 case 2 :
 		 				 ob.facultydisplay();
 		 				 break;
 		 			 case 3 :
 		 				 ob.facultyupdate();
 		 				 break;
 		 			 case 4 :
 		 				ob.facultydelete();
 		 				 break;
 		 			 case 5 :
 		 				 System.exit(0);
 		 				 
 		 			 default :
 		 				 ob.closeresources();
 		 			}
 		 		}
 		 	}
 		 	else {
 		 		System.out.println("Wrong Password!!!\nTry Again");
 		 	}
 		 }
 		 System.out.println("You reached the limit.\nPlease try again after few minutes.");
 		 System.exit(0);
	}
	
	finally
	{
		ob.closeresources();
	}
	
		

	}
}
