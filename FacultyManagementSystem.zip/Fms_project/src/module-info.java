/**
 * 
 */
/**
 * 
 */
module Fms_project {
	requires java.sql;
	requires mysql.connector.java;
}